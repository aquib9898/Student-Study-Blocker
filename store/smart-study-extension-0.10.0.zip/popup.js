// Status only. The extension has no controls of its own: every setting lives
// in the desktop app, and the extension only enforces them.

function send(type) {
  return new Promise((resolve) => chrome.runtime.sendMessage({ type }, resolve));
}

// Until the lock ends: its own time, or a "Break lock early" countdown that
// finishes first.
function fmtRemaining(lock) {
  if (!lock?.IsLocked) return "none";
  let remainingMs = lock.DurationMs - lock.ElapsedMs;
  if (lock.Break) remainingMs = Math.min(remainingMs, lock.Break.DurationMs - lock.Break.ElapsedMs);
  const mins = Math.round(Math.max(0, remainingMs) / 60000);
  const left = mins < 60 ? `${mins} min left` : `${Math.floor(mins / 60)}h ${mins % 60}m left`;
  return lock.Break ? `${left}, ending early` : left;
}

async function render() {
  const result = await send("get-status");
  const serviceEl = document.getElementById("service");
  const lockEl = document.getElementById("lock");
  const sitesEl = document.getElementById("sites");
  const noteEl = document.getElementById("note");

  if (result?.connected) {
    serviceEl.innerHTML = '<span class="dot ok"></span>connected';
    const lock = result.status.Lock;
    lockEl.textContent = fmtRemaining(lock);
    const sites = lock.Rules?.BlockedDomains ?? [];
    sitesEl.textContent = sites.length ? `${sites.length}` : "0";
    const notes = [];
    if (lock.IsLocked || sites.some((s) => s.toLowerCase() === "youtube.com/shorts")) notes.push("Shorts blocked.");
    if (lock.Rules?.ExtensionEnabled === false) {
      notes.push("Switched off in the app: YouTube isn't filtered or decluttered.");
    } else {
      if (lock.Rules?.EducationOnly) notes.push("Education-only mode on.");
      const declutter = lock.Rules?.Declutter ?? [];
      if (declutter.length) notes.push(`Declutter: ${declutter.length} active.`);
    }
    noteEl.textContent = notes.join(" ");
  } else {
    serviceEl.innerHTML = '<span class="dot bad"></span>not connected';
    lockEl.textContent = "—";
    sitesEl.textContent = "—";
    noteEl.textContent = result?.error ?? "";
  }
}

render();
